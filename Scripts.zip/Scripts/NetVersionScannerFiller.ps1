# Filip Verlee
# Test Script

$a = Get-Content -path D:\Scripts\ServerList.txt

$results = foreach ($i in $a)
    {

    Add-Content 'D:\Scripts\App\NetVersionScanner\NetVersionScanner.fve.bat' "NETVersionScanner.exe `"\\$i\d$\Inetpub`" > SBE074.csv `r`nNETVersionScanner.exe `"\\$i\d$\Programmas`" > SBE074.csv"
    
    }#End foreach

& 'D:\Scripts\App\NetVersionScanner\NetVersionScanner.fve.bat'

Write-Host "Press any key to continue ..."

$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

Write-Host
Write-Host "Starwars Rules!"