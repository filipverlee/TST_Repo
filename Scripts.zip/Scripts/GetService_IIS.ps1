$a = Get-Content -path D:\Scripts\ServerList.txt

$results = foreach ($i in $a)
    {$i + "`n" + "==========================";Invoke-Command -ComputerName $i -ScriptBlock {

try{
Import-Module WebAdministration
Get-WebApplication

$webapps = Get-WebApplication
$list = @()
foreach ($webapp in get-childitem IIS:\AppPools\)
{
$name = "IIS:\AppPools\" + $webapp.name
$item = @{}

$item.WebAppName = $webapp.name
$item.Version = (Get-ItemProperty $name managedRuntimeVersion).Value
$item.State = (Get-WebAppPoolState -Name $webapp.name).Value
$item.UserIdentityType = $webapp.processModel.identityType
$item.Username = $webapp.processModel.userName
$item.Password = $webapp.processModel.password

$obj = New-Object PSObject -Property $item
$list += $obj
}

$list | Format-Table -a -Property "WebAppName", "Version", "State", "UserIdentityType", "Username", "Password"

# Get DDL Details (Yes this is very dirty)
Write-Output "DLL Versions D:\Inetpub"
Get-ChildItem -Path D:\Inetpub -Filter *.dll -Recurse | Select-Object -ExpandProperty VersionInfo

Write-Output ""

Write-Output "DLL Versions D:\Programmas"
Get-ChildItem -Path D:\Programmas -Filter *.dll -Recurse | Select-Object -ExpandProperty VersionInfo

Write-Output ""
Write-Output "End of $env:computername =================="
Write-Output ""

}catch
{
$ExceptionMessage = "Error in Line: " + $_.Exception.Line + ". " + $_.Exception.GetType().FullName + ": " + $_.Exception.Message + " Stacktrace: " + $_.Exception.StackTrace
$ExceptionMessage
}
}
}
$results | Out-File D:\Scripts\IIS_Details.txt